import { nanoid } from 'nanoid';
import type { ClientSession } from 'mongodb';
import { col, withTransaction } from '../db/database.js';
import { HttpError } from '../utils/httpError.js';
import type { LedgerReason } from '../types/index.js';

export async function credit(
  userId: string,
  amount: number,
  reason: LedgerReason,
  refId: string | null = null,
  session?: ClientSession
): Promise<void> {
  if (amount <= 0) throw new Error('credit amount must be positive');

  const run = async (s: ClientSession) => {
    const users = await col('users');
    const ledger = await col('coin_ledger');
    await users.updateOne({ _id: userId }, { $inc: { balance_nova: amount } }, { session: s });
    await ledger.insertOne(
      { _id: nanoid(), user_id: userId, amount, reason, ref_id: refId, created_at: new Date() },
      { session: s }
    );
  };

  if (session) {
    await run(session);
  } else {
    await withTransaction((s) => run(s));
  }
}

export async function debit(
  userId: string,
  amount: number,
  reason: LedgerReason,
  refId: string | null = null,
  session?: ClientSession
): Promise<void> {
  if (amount <= 0) throw new Error('debit amount must be positive');

  const run = async (s: ClientSession) => {
    const users = await col('users');
    const ledger = await col('coin_ledger');
    const updated = await users.findOneAndUpdate(
      { _id: userId, balance_nova: { $gte: amount } },
      { $inc: { balance_nova: -amount } },
      { session: s }
    );
    if (!updated) throw new HttpError(400, 'Số dư Nova không đủ');
    await ledger.insertOne(
      { _id: nanoid(), user_id: userId, amount: -amount, reason, ref_id: refId, created_at: new Date() },
      { session: s }
    );
  };

  if (session) {
    await run(session);
  } else {
    await withTransaction((s) => run(s));
  }
}

export function novaToVnd(nova: number, rate: number): number {
  return Math.round(nova * rate);
}
