import express from 'express';
import cookieParser from 'cookie-parser';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import rateLimit from 'express-rate-limit';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { env } from './config/env.js';
import { ensureReady } from './db/database.js';

import { authRouter } from './routes/auth.routes.js';
import { tasksRouter } from './routes/tasks.routes.js';
import { walletRouter } from './routes/wallet.routes.js';
import { referralRouter } from './routes/referral.routes.js';
import { leaderboardRouter } from './routes/leaderboard.routes.js';
import { adminRouter } from './routes/admin.routes.js';
import { redeemRouter } from './routes/redeem.routes.js';
import { creatorRouter } from './routes/creator.routes.js';
import { dailyRouter } from './routes/daily.routes.js';
import { webhooksRouter } from './routes/webhooks.routes.js';
import { botRouter } from './routes/bot.routes.js';
import { errorHandler } from './middleware/errorHandler.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();

app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: new URL(env.clientUrl).origin, credentials: true }));
app.use(express.json());
app.use(cookieParser());
app.use(morgan(env.nodeEnv === 'production' ? 'combined' : 'dev'));

const router = express.Router();

router.use('/api', async (req, res, next) => {
  try {
    await ensureReady();
    next();
  } catch (err) {
    next(err);
  }
});

router.use('/api', rateLimit({ windowMs: 60_000, max: 120 }));
router.use('/api/tasks/:id/start', rateLimit({ windowMs: 60_000, max: 10 }));
router.use(
  ['/api/auth/login', '/api/auth/register', '/api/auth/forgot-password', '/api/auth/reset-password'],
  rateLimit({ windowMs: 60_000, max: 8, standardHeaders: true, legacyHeaders: false })
);

router.use('/api/auth', authRouter);
router.use('/api/tasks', tasksRouter);
router.use('/api/wallet', walletRouter);
router.use('/api/referral', referralRouter);
router.use('/api/leaderboard', leaderboardRouter);
router.use('/api/admin', adminRouter);
router.use('/api/redeem', redeemRouter);
router.use('/api/creator', creatorRouter);
router.use('/api/daily', dailyRouter);
router.use('/api/card2k', webhooksRouter);
router.use('/api/bot', botRouter);

if (!process.env.VERCEL) {
  const clientDist = path.resolve(__dirname, '../public');
  router.use(express.static(clientDist));
  router.get('*', (req, res, next) => {
    if (req.path.startsWith('/api')) return next();
    res.sendFile(path.join(clientDist, 'index.html'), (err) => {
      if (err) next();
    });
  });
}

if (env.basePath) {
  app.use(env.basePath, router);
  app.get('/', (req, res) => res.redirect(env.basePath));
} else {
  app.use(router);
}

app.use(errorHandler);

export { app };
