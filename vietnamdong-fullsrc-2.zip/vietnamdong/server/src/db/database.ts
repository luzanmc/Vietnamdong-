import { MongoClient, type Db, type ClientSession, type Collection, type Document } from 'mongodb';

const uri = process.env.DATABASE_URL || process.env.MONGODB_URI;
const dbName = process.env.MONGODB_DB || 'vietnamdong';

let client: MongoClient | null = null;
let dbPromise: Promise<Db> | null = null;

function getClient(): MongoClient {
  if (!uri) throw new Error('DATABASE_URL (hoặc MONGODB_URI) chưa được cấu hình');
  if (!client) client = new MongoClient(uri, { maxPoolSize: Number(process.env.MONGO_POOL_MAX || 10) });
  return client;
}

export async function getDb(): Promise<Db> {
  if (!dbPromise) {
    const c = getClient();
    dbPromise = c.connect().then(() => c.db(dbName));
  }
  return dbPromise;
}

export function col<T extends Document = Document>(name: string): Promise<Collection<T>> {
  return getDb().then((db) => db.collection<T>(name));
}

export async function withTransaction<T>(fn: (session: ClientSession) => Promise<T>): Promise<T> {
  const c = getClient();
  await getDb();
  const session = c.startSession();
  try {
    let result: T;
    await session.withTransaction(async () => {
      result = await fn(session);
    });
    return result!;
  } finally {
    await session.endSession();
  }
}

let readyPromise: Promise<void> | null = null;

export function ensureReady(): Promise<void> {
  if (!readyPromise) readyPromise = bootstrap();
  return readyPromise;
}

async function bootstrap(): Promise<void> {
  const db = await getDb();

  await db.collection('users').createIndex({ discord_id: 1 }, { unique: true, sparse: true });
  await db.collection('users').createIndex({ google_sub: 1 }, { unique: true, sparse: true });
  await db.collection('users').createIndex({ email: 1 }, { unique: true, sparse: true });
  await db.collection('users').createIndex({ username: 1 }, { unique: true });
  await db.collection('users').createIndex({ referred_by: 1 });
  await db.collection('users').createIndex({ creator_code_id: 1 });

  await db.collection('creator_codes').createIndex({ code: 1 }, { unique: true });
  await db.collection('creator_codes').createIndex({ owner_user_id: 1 });

  await db.collection('task_attempts').createIndex({ token: 1 }, { unique: true });
  await db.collection('task_attempts').createIndex({ user_id: 1, task_id: 1, status: 1, created_at: 1 });

  await db.collection('coin_ledger').createIndex({ user_id: 1, created_at: -1 });
  await db.collection('coin_ledger').createIndex({ reason: 1, created_at: -1 });

  await db.collection('withdrawals').createIndex({ user_id: 1, created_at: -1 });
  await db.collection('withdrawals').createIndex({ status: 1 });

  await db.collection('redeem_orders').createIndex({ user_id: 1, created_at: -1 });
  await db.collection('redeem_orders').createIndex({ status: 1 });

  await db.collection('password_resets').createIndex({ token_hash: 1 }, { unique: true });
  await db.collection('email_verifications').createIndex({ token_hash: 1 }, { unique: true });

  await db.collection('daily_claims').createIndex({ user_id: 1, claim_date: 1 }, { unique: true });

  const taskCount = await db.collection('tasks').countDocuments();
  if (taskCount === 0) {
    const seed = [
      ['task_0', 'yeumoney', 'Uptolink Social', 3, 1000, 0, 1],
      ['task_1', 'yeumoney', 'Uptolink Step 2', 3, 1000, 0, 2],
      ['task_2', 'yeumoney', 'Uptolink Step 3', 5, 1000, 0, 3],
      ['task_3', 'yeumoney', 'Uptolink Step 4', 5, 1000, 0, 4],
      ['task_4', 'link4m', 'Link4m', 2, 2, 0, 5],
      ['task_5', 'traffic68', 'Traffic68', 2, 4, 0, 6],
      ['task_6', 'phienchoso', 'TrafficVN', 2, 3, 1, 7],
      ['task_7', 'nhapma', 'Nhapma', 2, 4, 0, 8],
    ] as const;
    await db.collection('tasks').insertMany(
      seed.map(([id, provider_key, name, reward_nova, daily_limit, is_hot, sort_order]) => ({
        _id: id as any,
        provider_key,
        name,
        reward_nova,
        daily_limit,
        is_hot,
        active: 1,
        sort_order,
      }))
    );
  }

  const redeemCount = await db.collection('redeem_items').countDocuments();
  if (redeemCount === 0) {
    const items = [
      ['redeem_seed_0', 'game_topup', 'robux', '800 Robux (qua Gamepass)', 400, 'roblox_gamepass_link', null, null],
      ['redeem_seed_1', 'game_topup', 'robux_vng', '1000 Robux VNG', 480, 'game_uid', null, null],
      ['redeem_seed_2', 'game_topup', 'lienquan', '100 Quân Huy Liên Quân', 60, 'game_uid', null, null],
      ['redeem_seed_3', 'game_topup', 'freefire', '100 Kim Cương Free Fire', 65, 'game_uid', null, null],
      ['redeem_seed_4', 'game_topup', 'valorant', '475 VP Valorant', 300, 'game_uid', null, null],
      ['redeem_seed_5', 'game_topup', 'pubg', '600 UC PUBG Mobile', 350, 'game_uid', null, null],
      ['redeem_seed_6', 'game_topup', 'fcmobile', '100 FC Points (FC Mobile VN)', 70, 'game_uid', null, null],
      ['redeem_seed_7', 'wallet', 'steam', '50.000đ Ví Steam', 300, 'game_uid', null, null],
      ['redeem_seed_8', 'card', 'scratch_card', 'Thẻ cào Viettel 20.000đ', 120, 'phone_number', 'VIETTEL', 20000],
      ['redeem_seed_9', 'card', 'scratch_card', 'Thẻ cào Mobifone 20.000đ', 120, 'phone_number', 'MOBIFONE', 20000],
    ] as const;
    await db.collection('redeem_items').insertMany(
      items.map(([id, category, provider_key, label, price_nova, requires_field, telco, denomination], i) => ({
        _id: id as any,
        category,
        provider_key,
        label,
        price_nova,
        requires_field,
        telco,
        denomination,
        active: 1,
        sort_order: i,
      }))
    );
  }
}
