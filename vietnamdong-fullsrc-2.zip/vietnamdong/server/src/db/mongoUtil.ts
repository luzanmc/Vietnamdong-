export function withId<T extends { _id: any }>(doc: T | null | undefined): (Omit<T, '_id'> & { id: string }) | undefined {
  if (!doc) return undefined;
  const { _id, ...rest } = doc as any;
  return { ...rest, id: _id } as any;
}

export function withIds<T extends { _id: any }>(docs: T[]): (Omit<T, '_id'> & { id: string })[] {
  return docs.map((d) => withId(d)!);
}
