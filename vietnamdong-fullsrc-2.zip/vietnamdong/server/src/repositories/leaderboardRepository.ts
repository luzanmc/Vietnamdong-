import { col } from '../db/database.js';

export interface LeaderboardRow {
  username: string;
  avatar_url: string | null;
  earned: number;
}

async function users() {
  return col<any>('users');
}
async function ledger() {
  return col<any>('coin_ledger');
}

async function topByWindow(since: Date | null): Promise<LeaderboardRow[]> {
  const l = await ledger();
  const match: Record<string, unknown> = { reason: 'task_reward' };
  if (since) match.created_at = { $gte: since };

  const rows = await l
    .aggregate([
      { $match: match },
      { $group: { _id: '$user_id', earned: { $sum: '$amount' } } },
      { $sort: { earned: -1 } },
      { $limit: 20 },
      { $lookup: { from: 'users', localField: '_id', foreignField: '_id', as: 'user' } },
      { $unwind: '$user' },
      { $project: { _id: 0, username: '$user.username', avatar_url: '$user.avatar_url', earned: 1 } },
    ])
    .toArray();

  return rows as LeaderboardRow[];
}

export async function weeklyTop(): Promise<LeaderboardRow[]> {
  const since = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
  return topByWindow(since);
}

export async function dailyTop(): Promise<LeaderboardRow[]> {
  const since = new Date();
  since.setUTCHours(0, 0, 0, 0);
  return topByWindow(since);
}

export async function recordDaily(): Promise<(LeaderboardRow & { day: string })[]> {
  const l = await ledger();
  const rows = await l
    .aggregate([
      { $match: { reason: 'task_reward' } },
      {
        $group: {
          _id: { user_id: '$user_id', day: { $dateToString: { format: '%Y-%m-%d', date: '$created_at' } } },
          earned: { $sum: '$amount' },
        },
      },
      { $sort: { earned: -1 } },
      { $limit: 10 },
      { $lookup: { from: 'users', localField: '_id.user_id', foreignField: '_id', as: 'user' } },
      { $unwind: '$user' },
      { $project: { _id: 0, username: '$user.username', avatar_url: '$user.avatar_url', day: '$_id.day', earned: 1 } },
    ])
    .toArray();
  return rows as any;
}

export async function myChart(userId: string): Promise<{ day: string; net: number }[]> {
  const l = await ledger();
  const since = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
  const rows = await l
    .aggregate([
      { $match: { user_id: userId, created_at: { $gte: since } } },
      { $group: { _id: { $dateToString: { format: '%Y-%m-%d', date: '$created_at' } }, net: { $sum: '$amount' } } },
      { $sort: { _id: 1 } },
      { $project: { _id: 0, day: '$_id', net: 1 } },
    ])
    .toArray();
  return rows as any;
}
