import { col } from '../db/database.js';
import { withId, withIds } from '../db/mongoUtil.js';
import type { RedeemItem, RedeemOrder } from '../types/index.js';

interface RedeemItemDoc extends Omit<RedeemItem, 'id'> {
  _id: string;
}
interface RedeemOrderDoc extends Omit<RedeemOrder, 'id'> {
  _id: string;
}

async function items() {
  return col<RedeemItemDoc>('redeem_items');
}
async function orders() {
  return col<RedeemOrderDoc>('redeem_orders');
}
async function users() {
  return col<any>('users');
}

export async function listActiveRedeemItems(): Promise<RedeemItem[]> {
  const docs = await (await items()).find({ active: 1 }).sort({ category: 1, sort_order: 1 }).toArray();
  return withIds(docs) as any;
}

export async function getActiveRedeemItem(id: string): Promise<RedeemItem | undefined> {
  const doc = await (await items()).findOne({ _id: id, active: 1 });
  return withId(doc);
}

export async function createRedeemOrder(id: string, userId: string, itemId: string, destination: string, priceNova: number): Promise<void> {
  await (await orders()).insertOne({
    _id: id,
    user_id: userId,
    item_id: itemId,
    destination,
    price_nova: priceNova,
    status: 'pending',
    result_data: null,
    admin_note: null,
    created_at: new Date(),
    processed_at: null,
  });
}

export async function markRedeemOrderFulfilled(id: string, resultData: string): Promise<void> {
  await (await orders()).updateOne(
    { _id: id, status: 'pending' },
    { $set: { status: 'fulfilled', processed_at: new Date(), result_data: resultData } }
  );
}

export async function markRedeemOrderRejected(id: string, resultData: string | null, note: string): Promise<void> {
  await (await orders()).updateOne(
    { _id: id },
    { $set: { status: 'rejected', processed_at: new Date(), result_data: resultData, admin_note: note } }
  );
}

export async function setRedeemOrderResultData(id: string, resultData: string): Promise<void> {
  await (await orders()).updateOne({ _id: id }, { $set: { result_data: resultData } });
}

export async function listRedeemOrdersForUser(userId: string): Promise<(Partial<RedeemOrder> & { label: string; category: string })[]> {
  const docs = await (await orders()).find({ user_id: userId }).sort({ created_at: -1 }).toArray();
  const itemDocs = await (await items()).find({ _id: { $in: docs.map((d) => d.item_id) } }).toArray();
  const itemMap = new Map(itemDocs.map((i) => [i._id, i]));
  const merged = docs.map((o) => ({
    id: o._id,
    price_nova: o.price_nova,
    status: o.status,
    result_data: o.result_data,
    created_at: o.created_at,
    label: itemMap.get(o.item_id)?.label ?? 'unknown',
    category: itemMap.get(o.item_id)?.category ?? 'unknown',
  }));
  return merged as any;
}

export async function listAllRedeemOrdersAdmin(): Promise<(RedeemOrder & { username: string; label: string; category: string; requires_field: string })[]> {
  const docs = await (await orders()).find({}).toArray();
  const itemDocs = await (await items()).find({ _id: { $in: docs.map((d) => d.item_id) } }).toArray();
  const itemMap = new Map(itemDocs.map((i) => [i._id, i]));
  const u = await users();
  const userDocs = await u.find({ _id: { $in: docs.map((d) => d.user_id) } }, { projection: { username: 1 } }).toArray();
  const userMap = new Map(userDocs.map((x: any) => [x._id, x.username]));

  const merged = docs.map((o) => ({
    ...o,
    username: userMap.get(o.user_id) || 'unknown',
    label: itemMap.get(o.item_id)?.label ?? 'unknown',
    category: itemMap.get(o.item_id)?.category ?? 'unknown',
    requires_field: itemMap.get(o.item_id)?.requires_field ?? '',
  }));
  merged.sort((a, b) => {
    if (a.status === 'pending' && b.status !== 'pending') return -1;
    if (a.status !== 'pending' && b.status === 'pending') return 1;
    return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
  });
  return withIds(merged as any) as any;
}

export async function getPendingRedeemOrder(id: string): Promise<RedeemOrder | undefined> {
  const doc = await (await orders()).findOne({ _id: id, status: 'pending' });
  return withId(doc);
}

export async function findPendingOrderByRequestOrTrans(requestId: string, transId: string): Promise<RedeemOrder | undefined> {
  const doc = await (await orders()).findOne({
    status: 'pending',
    $or: [
      { result_data: { $regex: requestId, $options: 'i' } },
      { result_data: { $regex: transId, $options: 'i' } },
    ],
  });
  return withId(doc);
}
