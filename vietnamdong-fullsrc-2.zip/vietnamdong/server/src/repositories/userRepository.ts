import type { ClientSession } from 'mongodb';
import { col } from '../db/database.js';
import { withId, withIds } from '../db/mongoUtil.js';
import type { User } from '../types/index.js';

interface UserDoc extends Omit<User, 'id'> {
  _id: string;
}

async function users() {
  return col<UserDoc>('users');
}

export async function getUserById(id: string, session?: ClientSession): Promise<User | undefined> {
  const doc = await (await users()).findOne({ _id: id }, { session });
  return withId(doc);
}

export async function getUserByDiscordId(discordId: string): Promise<User | undefined> {
  const doc = await (await users()).findOne({ discord_id: discordId });
  return withId(doc);
}

export async function getUserByGoogleSub(sub: string): Promise<User | undefined> {
  const doc = await (await users()).findOne({ google_sub: sub });
  return withId(doc);
}

export async function getUserByUsername(username: string): Promise<User | undefined> {
  const doc = await (await users()).findOne({ username });
  return withId(doc);
}

export async function getUserByEmail(email: string): Promise<User | undefined> {
  const doc = await (await users()).findOne({ email: email.toLowerCase() });
  return withId(doc);
}

export async function createUserWithPassword(
  id: string,
  email: string,
  username: string,
  passwordHash: string
): Promise<void> {
  await (await users()).insertOne({
    _id: id,
    discord_id: null,
    google_sub: null,
    email: email.toLowerCase(),
    password_hash: passwordHash,
    email_verified: 0,
    username,
    avatar_url: null,
    role: 'user',
    balance_nova: 0,
    total_redeemed_nova: 0,
    referred_by: null,
    creator_code_id: null,
    streak_days: 0,
    streak_last_date: null,
    created_at: new Date() as any,
  });
}

export async function setUserPasswordHash(userId: string, passwordHash: string): Promise<void> {
  await (await users()).updateOne({ _id: userId }, { $set: { password_hash: passwordHash } });
}

export async function markEmailVerified(userId: string): Promise<void> {
  await (await users()).updateOne({ _id: userId }, { $set: { email_verified: 1 } });
}

export async function createUserFromDiscord(
  id: string,
  discordId: string,
  username: string,
  avatarUrl: string | null
): Promise<void> {
  await (await users()).insertOne({
    _id: id,
    discord_id: discordId,
    google_sub: null,
    email: null,
    password_hash: null,
    email_verified: 0,
    username,
    avatar_url: avatarUrl,
    role: 'user',
    balance_nova: 0,
    total_redeemed_nova: 0,
    referred_by: null,
    creator_code_id: null,
    streak_days: 0,
    streak_last_date: null,
    created_at: new Date() as any,
  });
}

export async function updateUserFromDiscord(id: string, username: string, avatarUrl: string | null): Promise<void> {
  await (await users()).updateOne({ _id: id }, { $set: { username, avatar_url: avatarUrl } });
}

export async function createUserFromGoogle(
  id: string,
  googleSub: string,
  username: string,
  avatarUrl: string | null
): Promise<void> {
  await (await users()).insertOne({
    _id: id,
    discord_id: null,
    google_sub: googleSub,
    email: null,
    password_hash: null,
    email_verified: 0,
    username,
    avatar_url: avatarUrl,
    role: 'user',
    balance_nova: 0,
    total_redeemed_nova: 0,
    referred_by: null,
    creator_code_id: null,
    streak_days: 0,
    streak_last_date: null,
    created_at: new Date() as any,
  });
}

export async function setReferredBy(userId: string, referrerId: string): Promise<void> {
  await (await users()).updateOne({ _id: userId }, { $set: { referred_by: referrerId } });
}

export async function setCreatorCode(userId: string, creatorCodeId: string): Promise<void> {
  await (await users()).updateOne({ _id: userId }, { $set: { creator_code_id: creatorCodeId } });
}

export async function searchUsers(
  query: string,
  limit = 50
): Promise<Pick<User, 'id' | 'username' | 'balance_nova' | 'role' | 'created_at'>[]> {
  const docs = await (await users())
    .find({ username: { $regex: query, $options: 'i' } }, { projection: { username: 1, balance_nova: 1, role: 1, created_at: 1 } })
    .sort({ created_at: -1 })
    .limit(limit)
    .toArray();
  return withIds(docs as any) as any;
}

export async function adjustUserBalanceRaw(userId: string, delta: number): Promise<void> {
  await (await users()).updateOne({ _id: userId }, { $inc: { balance_nova: delta } });
}

export async function updateStreak(
  userId: string,
  streakDays: number,
  streakLastDate: string,
  session?: ClientSession
): Promise<void> {
  await (await users()).updateOne(
    { _id: userId },
    { $set: { streak_days: streakDays, streak_last_date: streakLastDate } },
    { session }
  );
}

export async function countReferredUsers(referrerId: string): Promise<Pick<User, 'username' | 'created_at'>[]> {
  const docs = await (await users())
    .find({ referred_by: referrerId }, { projection: { username: 1, created_at: 1 } })
    .sort({ created_at: -1 })
    .toArray();
  return docs as any;
}

export async function countAllUsers(): Promise<number> {
  return (await users()).countDocuments();
}

export async function sumReferralBonusEarned(userId: string): Promise<number> {
  const ledger = await col<any>('coin_ledger');
  const result = await ledger
    .aggregate([{ $match: { user_id: userId, reason: 'referral_bonus' } }, { $group: { _id: null, total: { $sum: '$amount' } } }])
    .toArray();
  return result[0]?.total ?? 0;
}
