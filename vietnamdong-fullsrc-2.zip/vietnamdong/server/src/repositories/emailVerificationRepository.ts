import { col } from '../db/database.js';
import { withId } from '../db/mongoUtil.js';
import type { EmailVerification } from '../types/index.js';

interface EmailVerificationDoc extends Omit<EmailVerification, 'id'> {
  _id: string;
}

async function verifications() {
  return col<EmailVerificationDoc>('email_verifications');
}

export async function createEmailVerification(id: string, userId: string, tokenHash: string, expiresAt: string): Promise<void> {
  await (await verifications()).insertOne({
    _id: id,
    user_id: userId,
    token_hash: tokenHash,
    expires_at: expiresAt,
    used_at: null,
    created_at: new Date() as any,
  });
}

export async function findValidEmailVerification(tokenHash: string): Promise<EmailVerification | undefined> {
  const doc = await (await verifications()).findOne({
    token_hash: tokenHash,
    used_at: null,
    expires_at: { $gt: new Date().toISOString() },
  });
  return withId(doc);
}

export async function markEmailVerificationUsed(id: string): Promise<void> {
  await (await verifications()).updateOne({ _id: id }, { $set: { used_at: new Date() as any } });
}
