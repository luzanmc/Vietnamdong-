import type { ClientSession } from 'mongodb';
import { col } from '../db/database.js';
import { withId, withIds } from '../db/mongoUtil.js';
import type { CoinLedgerEntry, Withdrawal, WithdrawMethod } from '../types/index.js';

interface LedgerDoc extends Omit<CoinLedgerEntry, 'id'> {
  _id: string;
}
interface WithdrawalDoc extends Omit<Withdrawal, 'id'> {
  _id: string;
}
interface TransferDoc {
  _id: string;
  from_user_id: string;
  to_user_id: string;
  amount_nova: number;
  created_at: Date;
}

async function ledger() {
  return col<LedgerDoc>('coin_ledger');
}
async function withdrawals() {
  return col<WithdrawalDoc>('withdrawals');
}
async function transfers() {
  return col<TransferDoc>('transfers');
}
async function users() {
  return col<any>('users');
}

export async function getLedgerForUser(userId: string, limit = 50): Promise<CoinLedgerEntry[]> {
  const docs = await (await ledger()).find({ user_id: userId }).sort({ created_at: -1 }).limit(limit).toArray();
  return withIds(docs) as any;
}

export async function createWithdrawal(
  id: string,
  userId: string,
  amountNova: number,
  amountVnd: number,
  method: WithdrawMethod,
  destination: string
): Promise<void> {
  await (await withdrawals()).insertOne({
    _id: id,
    user_id: userId,
    amount_nova: amountNova,
    amount_vnd: amountVnd,
    method,
    destination,
    status: 'pending',
    admin_note: null,
    created_at: new Date(),
    processed_at: null,
  });
}

export async function listWithdrawalsForUser(userId: string): Promise<Partial<Withdrawal>[]> {
  const docs = await (await withdrawals()).find({ user_id: userId }).sort({ created_at: -1 }).toArray();
  return withIds(docs as any) as any;
}

export async function listAllWithdrawalsAdmin(): Promise<(Withdrawal & { username: string })[]> {
  const docs = await (await withdrawals()).find({}).toArray();
  const u = await users();
  const usernames = await u
    .find({ _id: { $in: docs.map((d) => d.user_id) } }, { projection: { username: 1 } })
    .toArray();
  const nameMap = new Map(usernames.map((x: any) => [x._id, x.username]));
  const merged = docs.map((d) => ({ ...d, username: nameMap.get(d.user_id) || 'unknown' }));
  merged.sort((a, b) => {
    if (a.status === 'pending' && b.status !== 'pending') return -1;
    if (a.status !== 'pending' && b.status === 'pending') return 1;
    return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
  });
  return withIds(merged as any) as any;
}

export async function getPendingWithdrawal(id: string): Promise<Withdrawal | undefined> {
  const doc = await (await withdrawals()).findOne({ _id: id, status: 'pending' });
  return withId(doc);
}

export async function markWithdrawalPaid(id: string, note: string | null): Promise<void> {
  await (await withdrawals()).updateOne(
    { _id: id, status: 'pending' },
    { $set: { status: 'paid', processed_at: new Date(), admin_note: note } }
  );
}

export async function markWithdrawalRejected(id: string, note: string): Promise<void> {
  await (await withdrawals()).updateOne({ _id: id }, { $set: { status: 'rejected', processed_at: new Date(), admin_note: note } });
}

export async function createTransferRecord(id: string, fromUserId: string, toUserId: string, amount: number): Promise<void> {
  await (await transfers()).insertOne({ _id: id, from_user_id: fromUserId, to_user_id: toUserId, amount_nova: amount, created_at: new Date() });
}

export async function countPendingWithdrawals(): Promise<number> {
  return (await withdrawals()).countDocuments({ status: 'pending' });
}
