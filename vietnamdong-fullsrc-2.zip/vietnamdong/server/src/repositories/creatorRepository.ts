import { col } from '../db/database.js';
import { withId, withIds } from '../db/mongoUtil.js';
import type { CreatorCode } from '../types/index.js';

interface CreatorCodeDoc extends Omit<CreatorCode, 'id'> {
  _id: string;
}

async function codes() {
  return col<CreatorCodeDoc>('creator_codes');
}
async function users() {
  return col<any>('users');
}
async function ledger() {
  return col<any>('coin_ledger');
}

export async function getCreatorCodeByOwner(ownerUserId: string): Promise<CreatorCode | undefined> {
  const doc = await (await codes()).findOne({ owner_user_id: ownerUserId });
  return withId(doc);
}

export async function getActiveCreatorCodeByCode(code: string): Promise<CreatorCode | undefined> {
  const doc = await (await codes()).findOne({ code, active: 1 });
  return withId(doc);
}

export async function countUsersUsingCode(creatorCodeId: string): Promise<number> {
  return (await users()).countDocuments({ creator_code_id: creatorCodeId });
}

export async function createCreatorCode(id: string, code: string, ownerUserId: string, bonusPercent: number): Promise<void> {
  await (await codes()).insertOne({
    _id: id,
    code,
    owner_user_id: ownerUserId,
    bonus_percent: bonusPercent,
    active: 1,
    created_at: new Date() as any,
  });
}

export async function updateCreatorCodeAdmin(id: string, patch: { bonus_percent?: number; active?: number }): Promise<void> {
  const set: Record<string, unknown> = {};
  if (patch.bonus_percent !== undefined) set.bonus_percent = patch.bonus_percent;
  if (patch.active !== undefined) set.active = patch.active;
  if (Object.keys(set).length === 0) return;
  await (await codes()).updateOne({ _id: id }, { $set: set });
}

export async function listCreatorCodesAdmin(): Promise<(CreatorCode & { owner_username: string; used_by_count: number })[]> {
  const docs = await (await codes()).find({}).sort({ created_at: -1 }).toArray();
  const u = await users();
  const owners = await u.find({ _id: { $in: docs.map((d) => d.owner_user_id) } }, { projection: { username: 1 } }).toArray();
  const ownerMap = new Map(owners.map((x: any) => [x._id, x.username]));
  const counts = await Promise.all(docs.map((d) => u.countDocuments({ creator_code_id: d._id })));

  return withIds(
    docs.map((d, i) => ({ ...d, owner_username: ownerMap.get(d.owner_user_id) || 'unknown', used_by_count: counts[i] }))
  ) as any;
}

export async function getCreatorForUser(userId: string): Promise<{ id: string; owner_user_id: string; bonus_percent: number } | undefined> {
  const u = await users();
  const user = await u.findOne({ _id: userId });
  if (!user?.creator_code_id) return undefined;
  const code = await (await codes()).findOne({ _id: user.creator_code_id, active: 1 });
  if (!code) return undefined;
  return { id: userId, owner_user_id: code.owner_user_id, bonus_percent: code.bonus_percent };
}

export async function sumCreatorBonusEarned(ownerUserId: string): Promise<number> {
  const l = await ledger();
  const result = await l
    .aggregate([{ $match: { user_id: ownerUserId, reason: 'creator_bonus' } }, { $group: { _id: null, total: { $sum: '$amount' } } }])
    .toArray();
  return result[0]?.total ?? 0;
}
