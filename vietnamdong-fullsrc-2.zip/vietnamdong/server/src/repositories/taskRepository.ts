import type { ClientSession } from 'mongodb';
import { col } from '../db/database.js';
import { withId, withIds } from '../db/mongoUtil.js';
import type { Task, TaskAttempt } from '../types/index.js';

interface TaskDoc extends Omit<Task, 'id'> {
  _id: string;
}
interface AttemptDoc extends Omit<TaskAttempt, 'id'> {
  _id: string;
}

async function tasks() {
  return col<TaskDoc>('tasks');
}
async function attempts() {
  return col<AttemptDoc>('task_attempts');
}

export async function listActiveTasks(): Promise<Task[]> {
  const docs = await (await tasks()).find({ active: 1 }).sort({ sort_order: 1 }).toArray();
  return withIds(docs) as any;
}

export async function getTaskById(id: string): Promise<Task | undefined> {
  const doc = await (await tasks()).findOne({ _id: id, active: 1 });
  return withId(doc);
}

export async function getAnyTaskById(id: string): Promise<Task | undefined> {
  const doc = await (await tasks()).findOne({ _id: id });
  return withId(doc);
}

export async function countCompletedAttemptsToday(taskId: string, userId: string): Promise<number> {
  const start = new Date();
  start.setUTCHours(0, 0, 0, 0);
  return (await attempts()).countDocuments({
    task_id: taskId,
    user_id: userId,
    status: 'completed',
    created_at: { $gte: start },
  });
}

export async function createAttempt(id: string, taskId: string, userId: string, token: string, shortUrl: string): Promise<void> {
  await (await attempts()).insertOne({
    _id: id,
    task_id: taskId,
    user_id: userId,
    token,
    status: 'pending',
    short_url: shortUrl,
    created_at: new Date(),
    completed_at: null,
  });
}

export async function getAttemptByToken(
  token: string
): Promise<(TaskAttempt & { task_name: string; reward_nova: number }) | undefined> {
  const attempt = await (await attempts()).findOne({ token });
  if (!attempt) return undefined;
  const task = await (await tasks()).findOne({ _id: attempt.task_id });
  return withId({ ...attempt, task_name: task?.name ?? 'unknown', reward_nova: task?.reward_nova ?? 0 } as any) as any;
}

export async function getPendingAttemptByToken(token: string): Promise<TaskAttempt | undefined> {
  const doc = await (await attempts()).findOne({ token, status: 'pending' });
  return withId(doc);
}

export async function markAttemptCompleted(attemptId: string): Promise<void> {
  await (await attempts()).updateOne({ _id: attemptId }, { $set: { status: 'completed', completed_at: new Date() } });
}

export async function listAllTasksAdmin(): Promise<Task[]> {
  const docs = await (await tasks()).find({}).sort({ sort_order: 1 }).toArray();
  return withIds(docs) as any;
}

export async function updateTaskAdmin(
  id: string,
  patch: { reward_nova?: number; daily_limit?: number; active?: number; is_hot?: number }
): Promise<void> {
  const set: Record<string, unknown> = {};
  if (patch.reward_nova !== undefined) set.reward_nova = patch.reward_nova;
  if (patch.daily_limit !== undefined) set.daily_limit = patch.daily_limit;
  if (patch.active !== undefined) set.active = patch.active;
  if (patch.is_hot !== undefined) set.is_hot = patch.is_hot;
  if (Object.keys(set).length === 0) return;
  await (await tasks()).updateOne({ _id: id }, { $set: set });
}

export async function sumTaskRewardOut(): Promise<number> {
  const ledger = await col<any>('coin_ledger');
  const result = await ledger
    .aggregate([{ $match: { reason: 'task_reward' } }, { $group: { _id: null, total: { $sum: '$amount' } } }])
    .toArray();
  return result[0]?.total ?? 0;
}
