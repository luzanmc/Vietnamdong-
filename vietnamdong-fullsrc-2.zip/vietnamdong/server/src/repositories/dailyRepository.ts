import type { ClientSession } from 'mongodb';
import { col } from '../db/database.js';

interface DailyClaimDoc {
  _id: string;
  user_id: string;
  claim_date: string;
  reward_nova: number;
  streak_day: number;
  created_at: Date;
}

async function claims() {
  return col<DailyClaimDoc>('daily_claims');
}

export async function getClaimForDate(userId: string, date: string): Promise<{ claim_date: string } | undefined> {
  const doc = await (await claims()).findOne({ user_id: userId, claim_date: date }, { projection: { claim_date: 1 } });
  return doc ?? undefined;
}

export async function createClaim(
  id: string,
  userId: string,
  date: string,
  rewardNova: number,
  streakDay: number,
  session?: ClientSession
): Promise<void> {
  await (await claims()).insertOne(
    { _id: id, user_id: userId, claim_date: date, reward_nova: rewardNova, streak_day: streakDay, created_at: new Date() },
    { session }
  );
}
