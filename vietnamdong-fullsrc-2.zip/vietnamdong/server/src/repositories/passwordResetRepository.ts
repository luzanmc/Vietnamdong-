import { col } from '../db/database.js';
import { withId } from '../db/mongoUtil.js';
import type { PasswordReset } from '../types/index.js';

interface PasswordResetDoc extends Omit<PasswordReset, 'id'> {
  _id: string;
}

async function resets() {
  return col<PasswordResetDoc>('password_resets');
}

export async function createPasswordReset(id: string, userId: string, tokenHash: string, expiresAt: string): Promise<void> {
  await (await resets()).insertOne({
    _id: id,
    user_id: userId,
    token_hash: tokenHash,
    expires_at: expiresAt,
    used_at: null,
    created_at: new Date() as any,
  });
}

export async function findValidPasswordReset(tokenHash: string): Promise<PasswordReset | undefined> {
  const doc = await (await resets()).findOne({
    token_hash: tokenHash,
    used_at: null,
    expires_at: { $gt: new Date().toISOString() },
  });
  return withId(doc);
}

export async function markPasswordResetUsed(id: string): Promise<void> {
  await (await resets()).updateOne({ _id: id }, { $set: { used_at: new Date() as any } });
}

export async function invalidatePendingResetsForUser(userId: string): Promise<void> {
  await (await resets()).updateMany({ user_id: userId, used_at: null }, { $set: { used_at: new Date() as any } });
}
