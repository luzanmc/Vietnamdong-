import { MongoClient } from 'mongodb';

const uri = process.env.DATABASE_URL || process.env.MONGODB_URI;
const dbName = process.env.MONGODB_DB || 'vietnamdong';

if (!uri) {
  throw new Error('DATABASE_URL (hoặc MONGODB_URI) chưa được cấu hình cho bot');
}

const client = new MongoClient(uri, { maxPoolSize: Number(process.env.MONGO_POOL_MAX || 3) });
const dbPromise = client.connect().then(() => client.db(dbName));

export interface BotUser {
  id: string;
  username: string;
  discord_id: string | null;
  balance_nova: number;
  total_redeemed_nova: number;
  streak_days: number;
}

export interface BotWithdrawal {
  amount_nova: number;
  amount_vnd: number;
  status: string;
  created_at: string;
}

export async function getBotUserByDiscordId(discordId: string): Promise<BotUser | undefined> {
  const db = await dbPromise;
  const doc = await db.collection<any>('users').findOne({ discord_id: discordId });
  if (!doc) return undefined;
  return {
    id: doc._id,
    username: doc.username,
    discord_id: doc.discord_id,
    balance_nova: doc.balance_nova,
    total_redeemed_nova: doc.total_redeemed_nova,
    streak_days: doc.streak_days,
  };
}

export async function getRecentWithdrawals(userId: string, limit = 5): Promise<BotWithdrawal[]> {
  const db = await dbPromise;
  const docs = await db
    .collection<any>('withdrawals')
    .find({ user_id: userId }, { projection: { amount_nova: 1, amount_vnd: 1, status: 1, created_at: 1 } })
    .sort({ created_at: -1 })
    .limit(limit)
    .toArray();
  return docs as any;
}
